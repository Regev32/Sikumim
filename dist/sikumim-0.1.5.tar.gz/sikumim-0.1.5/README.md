# Sikumim

## Introduction
A simple tool to quickly and easily download lecture notes (and more).

All notes are published with the courtesy of **Regev Yehezkel Imra**.

##  Instructions
1. Install the library:
    ```
    pip install sikumim
    ```
2. Run the following command to download course material:
    ```
    dl_lec <course-name> <output-path>
    ```
   For example,
   ```
   dl_lec Topology Desktop
   ```
